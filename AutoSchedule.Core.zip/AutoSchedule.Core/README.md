﻿# Auto Schedule
### Feature
This program is designed to **automatically generate class schedules**, given necessary class information.
### Prerequisite
The program needs **.NET Core 5.0 Runtime** to run. You can download it from [here](https://dotnet.microsoft.com/download/dotnet/5.0).
### Note for Contributing
Please create a new branch **dev_$FeatureName**. The master branch is only for release.
### Notice
This project is in active development.
### Credits 
✨Presented by [myfix16](https://github.com/myfix16) and [xen134](https://github.com/134ARG) 